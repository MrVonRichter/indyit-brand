IndyIT colours (Forest + Signal)

Paper  #F4F0DF  RGB 244 240 223
Forest #1F5A2E  RGB 31 90 46
Signal #25933E  RGB 37 147 62
Mint   #DCEFDF  RGB 220 239 223
Bark   #2E260F  RGB 46 38 15

IndyIT-Forest-Signal.ase  Adobe swatch file (Illustrator, InDesign, Photoshop).
indyit-colours.css  CSS variables for the web.
CMYK values in the guide are starting points. Proof before printing.
