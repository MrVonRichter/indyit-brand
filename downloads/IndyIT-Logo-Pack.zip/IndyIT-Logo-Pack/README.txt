IndyIT logo pack (v1.0, November 2026)

svg/  Use for screens and the web.
png/  Transparent, 4x. Use where SVG isn't accepted.
IndyIT-Lockup-Forest-Signal.ai  Illustrator source for print and production.

Versions: lockup, lockup-reversed (dark backgrounds), mark, mark-reversed,
lockup-onecolor-bark (single ink), lockup-onecolor-paper (single colour on dark).

Clear space: half the mark's height on every side.
Minimum size: lockup 120 px / 1 in; mark 24 px / 0.25 in.
Full rules: see the IndyIT brand guide.
